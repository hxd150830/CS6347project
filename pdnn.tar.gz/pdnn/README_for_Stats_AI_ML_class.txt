The code, and data to run the match outcome predicition dnn system are located in:
stats_AI_ML_class/
The key script to run is run_match_pred.sh.
This project uses elements from Yajie Miao's pdnn toolkit, available at:
https://github.com/yajiemiao/pdnn
