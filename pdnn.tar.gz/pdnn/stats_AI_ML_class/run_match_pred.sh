#!/bin/bash

# two variables you need to set
pdnndir=/home/sxr092820/tools/pdnn 
device=gpu0  # the device to be used. set it to "cpu" if you don't have GPUs

# export environment variables
export PYTHONPATH=$PYTHONPATH:$pdnndir
export THEANO_FLAGS=mode=FAST_RUN,device=$device,floatX=float32



# train DNN model
echo "Training the DNN model ..."
python $pdnndir/cmds/run_DNN.py --train-data "train.pickle.gz,random=True" \
                                --valid-data "cv.pickle.gz,random=True" \
                                --nnet-spec "25:512:512:512:10" --wdir ./ \
                                --l2-reg 0.0001 --lrate "C:0.08:1000" --model-save-step 20 \
                                --param-output-file match_pred.param --cfg-output-file match_pred.cfg  >& match_pred.training.log


echo "Extracting the test features ..."
python $pdnndir/cmds/run_Extract_Feats.py --data "test.pickle.gz" \
                                          --nnet-param match_pred.param --nnet-cfg match_pred.cfg \
                                          --output-file "classify.pickle.gz" --layer-index -1 \
                                          --batch-size 100


# This code is for match precition class project
# Stats AI in matchine learning
#res1: for n/w 25:512:512:10, iter = 200, lrate =0.01, train error= 51.36%
#res2:  25:512:512:10, iter = 200, lrate =0.1, training error= 34.179 %
#res3: "25:512:512:10", iter = 200, lrate =0.08, training error= 49.153%
#res4: 25:512:512:10", iter = 440, lrate =0.08, training error=  15.16%
#res5: 25:768:768:10", iter = 200, lrate =0.08, training error=  32.22%
#res6: 25:128:128:10", iter = 200, lrate =0.08, training error= 44.79%
#res7: 25:128:128:10", iter = 1000, lrate =0.08, training error= 24.60%
#res8: 25:128:128:128:10", iter = 200, lrate =0.08, training error= 47.20%
#res9: 25:128:128:128:10", iter = 440, lrate =0.08, training error= 37.82%
#res10:  25:512:512:512:10", iter = 200, lrate =0.08, training error=  35.15%
#res11:  25:512:512:512:10", iter = 1000, lrate =0.08, training error=  





